function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);
  noStroke();
}

function draw() {
  background(255); // Redraw the background each frame

  let numElements = 10;
  let spacing = width / numElements;
  let baseSize = spacing * 0.8;

  for (let i = 0; i < numElements; i++) {
    for (let j = 0; j < numElements; j++) {
      let x = spacing / 2 + i * spacing;
      let y = spacing / 2 + j * spacing;
      
      fill(180); // Gray
      let currentSize = baseSize;

      // The different element
      if (i === 5 && j === 5) {
        fill(255, 60, 60); // Bright Red
        
        // A sine wave creates a smooth pulse from -1 to 1.
        // We map this to a size change to make it pulse.
        // frameCount is the number of frames that have passed.
        let pulse = sin(frameCount * 0.1); 
        currentSize = baseSize + pulse * (baseSize * 0.5);
      }
      
      rect(x, y, currentSize, currentSize);
    }
  }
}